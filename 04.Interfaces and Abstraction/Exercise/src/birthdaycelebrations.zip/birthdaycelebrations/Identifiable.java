package birthdaycelebrations;

public interface Identifiable {
    String getId();
}
